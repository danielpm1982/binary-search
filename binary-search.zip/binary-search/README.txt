For running this console app,

open your console at this folder,

and type...

if on linux:
./start.bat

if on windows:
start.bat
